# Calculadora de notas

Programa en Java Swing, sin librerías externas.

## Cómo ejecutarlo

Abra la carpeta como proyecto en NetBeans y pulse F6.

## Cómo funciona

Ingrese código, nombre y tres notas (0 a 5, con coma o punto) y pulse **Calcular**. El resultado aparece junto al botón.

`Definitiva = nota1 × 0,30 + nota2 × 0,30 + nota3 × 0,40`

Desde 3,0 es **Aprobado**; por debajo, **Reprobado**.

## Clases (`src/edu/compensar/codigo/`)

- `Calculadora`: inicia el programa.
- `Estudiante`: guarda los datos, valida y calcula la definitiva.
- `VentanaCalculadora`: la ventana con los campos, el botón y el resultado.
