package edu.compensar.codigo;

public class Estudiante {

    private String codigo;
    private String nombre;
    private double nota1;
    private double nota2;
    private double nota3;

    public Estudiante(String codigo, String nombre, double nota1, double nota2, double nota3) {
        if (codigo.isBlank() || nombre.isBlank()) {
            throw new IllegalArgumentException("Ingrese el código y el nombre.");
        }

        if (!esNotaValida(nota1) || !esNotaValida(nota2) || !esNotaValida(nota3)) {
            throw new IllegalArgumentException("Las notas deben estar entre 0.0 y 5.0.");
        }

        this.codigo = codigo;
        this.nombre = nombre;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }

    private boolean esNotaValida(double nota) {
        return nota >= 0.0 && nota <= 5.0;
    }

    public double calcularDefinitiva() {
        double definitiva = nota1 * 0.30 + nota2 * 0.30 + nota3 * 0.40;
        return Math.round(definitiva * 100) / 100.0;
    }

    public String getEstado() {
        if (calcularDefinitiva() >= 3.0) {
            return "Aprobado";
        } else {
            return "Reprobado";
        }
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getNota1() {
        return nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public double getNota3() {
        return nota3;
    }
}
