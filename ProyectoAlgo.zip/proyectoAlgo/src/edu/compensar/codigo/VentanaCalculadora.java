package edu.compensar.codigo;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaCalculadora extends JFrame {

    private JTextField campoCodigo = new JTextField();
    private JTextField campoNombre = new JTextField();
    private JTextField campoNota1 = new JTextField();
    private JTextField campoNota2 = new JTextField();
    private JTextField campoNota3 = new JTextField();

    private DefaultTableModel modelo;
    private JTable tabla;

    public VentanaCalculadora() {
        setTitle("Registro de estudiantes y notas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel formulario = new JPanel(new GridLayout(6, 2, 5, 5));
        formulario.add(new JLabel("Código:"));
        formulario.add(campoCodigo);
        formulario.add(new JLabel("Nombre:"));
        formulario.add(campoNombre);
        formulario.add(new JLabel("Primera nota (30 %):"));
        formulario.add(campoNota1);
        formulario.add(new JLabel("Segunda nota (30 %):"));
        formulario.add(campoNota2);
        formulario.add(new JLabel("Tercera nota (40 %):"));
        formulario.add(campoNota3);

        JButton botonRegistrar = new JButton("Calcular y registrar");
        botonRegistrar.addActionListener(e -> calcularYRegistrar());
        formulario.add(botonRegistrar);

        JButton botonLimpiar = new JButton("Limpiar campos");
        botonLimpiar.addActionListener(e -> limpiarCampos());
        formulario.add(botonLimpiar);

        String[] columnas = {
            "Código", "Nombre", "Primera nota", "Segunda nota",
            "Tercera nota", "Definitiva", "Estado"
        };
        modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modelo);

        add(formulario, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        setSize(900, 450);
        setLocationRelativeTo(null);
    }

    private void calcularYRegistrar() {
        try {
            Estudiante estudiante = new Estudiante(
                campoCodigo.getText().trim(),
                campoNombre.getText().trim(),
                leerNota(campoNota1),
                leerNota(campoNota2),
                leerNota(campoNota3)
            );

            double definitiva = estudiante.calcularDefinitiva();

            modelo.addRow(new Object[] {
                estudiante.getCodigo(),
                estudiante.getNombre(),
                estudiante.getNota1(),
                estudiante.getNota2(),
                estudiante.getNota3(),
                String.format("%.2f", definitiva),
                estudiante.getEstado()
            });

            limpiarCampos();
            JOptionPane.showMessageDialog(this, "Estudiante registrado correctamente.");
        } catch (IllegalArgumentException error) {
            JOptionPane.showMessageDialog(this, error.getMessage(),
                "Dato inválido", JOptionPane.ERROR_MESSAGE);
        }
    }

    private double leerNota(JTextField campo) {
        try {
            return Double.parseDouble(campo.getText().trim().replace(',', '.'));
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException("Ingrese un número válido en las tres notas.");
        }
    }

    private void limpiarCampos() {
        campoCodigo.setText("");
        campoNombre.setText("");
        campoNota1.setText("");
        campoNota2.setText("");
        campoNota3.setText("");
        campoCodigo.requestFocus();
    }
}
